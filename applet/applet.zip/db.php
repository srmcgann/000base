<?php
	$db_user="id21284549_user";
	$db_pass="Chrome57253!*";
	$db_host="localhost";
	$db="id21284549_videodemos2";
	$baseDomain="efx.cantelope.org";
	$appletDomain="efx.cantelope.org";
  $legacyDomain="legacy.cantelope.org";
	$baseURL   ="http://$baseDomain";
  $legacyURL ="http://$legacyDomain";
	$appletURL ="http://$appletDomain/applet";
	$link = mysqli_connect($db_host, $db_user, $db_pass, $db);
?>
