<?php
	$db_user="id21601862_user";
	$db_pass="Chrome57253!*";
	$db_host="localhost";
	$db="id21601862_efx3";
	$baseDomain="efx3.cantelope.org";
	$appletDomain="efx3.cantelope.org";
  $legacyDomain="legacy.cantelope.org";
	$baseURL   ="http://$baseDomain";
  $legacyURL ="http://$legacyDomain";
	$appletURL ="http://$appletDomain/applet";
	$link = mysqli_connect($db_host, $db_user, $db_pass, $db);
?>
