<?php
  require("functions.php");
  drawMenu();
?>