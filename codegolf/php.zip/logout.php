<?php
	setcookie("id", "", time() - 3600);
	setcookie("session", "", time() - 3600);
?>