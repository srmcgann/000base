<?php
	$db_user="id21616125_user";
	$db_pass="Chrome57253!*";
	$db_host="localhost";
	$db="id21616125_multiplayer";
	$baseDomain="whr.run.place";
	$appletDomain="whr.run.place";
  $legacyDomain="legacy.cantelope.org";
	$baseURL   ="http://$baseDomain";
  $legacyURL ="http://$legacyDomain";
	$appletURL ="http://$appletDomain/applet";
	$link = mysqli_connect($db_host, $db_user, $db_pass, $db);
?>
