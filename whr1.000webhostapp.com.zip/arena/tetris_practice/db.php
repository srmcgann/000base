<?php
  $db_user="id21616125_user";
  $db_pass="Chrome57253!*";
  $db_host="localhost";
  $db="id21616125_multiplayer";
  $baseURL='whr1.000webhostapp.com/b/games/tetris';
  $link = mysqli_connect($db_host, $db_user, $db_pass, $db);
?>
