<?php 
  require('db.php');
  $data = json_decode(file_get_contents('php://input'));
  $userName = mysqli_real_escape_string($link, $data->{'userName'});
  $passhash = mysqli_real_escape_string($link, $data->{'passhash'});
  $newURL = mysqli_real_escape_string($link, $data->{'newURL'});
  $demoID = mysqli_real_escape_string($link, $data->{'demoID'});
  file_get_contents('vidThumb.php?id=' . $demoID);
  $sql = 'SELECT * FROM users WHERE name LIKE "'.$userName.'" AND passhash = "'.$passhash.'";';
  $res = mysqli_query($link, $sql);
  $success = false;
  if(mysqli_num_rows($res)){
    $row = mysqli_fetch_assoc($res);
    if($row['enabled']){
      if($row['admin']){
        $sql = 'UPDATE items SET videoLink = "'.$newURL.'" WHERE id = '.$demoID;
      } else {
        $sql = 'UPDATE items SET videoLink = "'.$newURL.'" WHERE id = '.$demoID . ' AND userID = ' . $row['id'];
      }
      mysqli_query($link, $sql);
      $success = true;
    }
  }
  echo json_encode([$success]);
?>
