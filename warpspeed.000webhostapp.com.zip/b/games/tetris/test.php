<?
  echo time();
?>
