<?php
	$db_user="id21607252_user";
	$db_pass="Chrome57253!*";
	$db_host="localhost";
	$db="id21607252_warpspeed";
	$baseDomain="warpspeed.000webhostapp.com";
	$appletDomain="warpspeed.000webhostapp.com";
  $legacyDomain="legacy.cantelope.org";
	$baseURL   ="https://$baseDomain";
  $legacyURL ="https://$legacyDomain";
	$appletURL ="https://$appletDomain/applet";
	$link = mysqli_connect($db_host, $db_user, $db_pass, $db);
?>
