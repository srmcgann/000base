<?php
	$db_user="id21257390_user";
	$db_pass="Chrome57253!*";
	$db_host="localhost";
	$db="id21257390_default";
	$baseDomain="0.cantelope.org";
	$appletDomain="0.cantelope.org";
  $legacyDomain="legacy.cantelope.org";
	$baseURL   ="http://$baseDomain";
  $legacyURL ="http://$legacyDomain";
	$appletURL ="http://$appletDomain/applet";
	$link = mysqli_connect($db_host, $db_user, $db_pass, $db);
?>
