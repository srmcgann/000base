<?php
	$db_user="id21601194_user";
	$db_pass="Chrome57253!*";
	$db_host="localhost";
	$db="id21601194_efx2";
	$baseDomain="efx2.cantelope.org";
	$appletDomain="efx2.cantelope.org";
  $legacyDomain="legacy.cantelope.org";
	$baseURL   ="http://$baseDomain";
  $legacyURL ="http://$legacyDomain";
	$appletURL ="http://$appletDomain/applet";
	$link = mysqli_connect($db_host, $db_user, $db_pass, $db);
?>
