<?php
  $db_user="id21553412_user";
  $db_pass="Chrome57253!*";
  $db_host="localhost";
  $db="id21553412_orbs3";
  $baseURL='demo.whitehotrobot.com';
  $link = mysqli_connect($db_host, $db_user, $db_pass, $db);
?>
